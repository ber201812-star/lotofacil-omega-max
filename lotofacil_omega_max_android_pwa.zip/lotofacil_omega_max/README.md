# LOTOFÁCIL Ω MAX

Aplicativo web/PWA gratuito para Android com:
- 3.721 concursos iniciais da base fornecida pelo usuário;
- cobertura combinatória exata de 14+/15 para cada jogo de 15 dezenas (151 resultados cobertos por jogo);
- seleção greedy de cobertura;
- otimização multiobjetivo;
- busca local / simulated annealing e etapa quantum-inspired (heurística, não computação quântica real);
- backtest walk-forward;
- PWA instalável na tela inicial do Android;
- atualização automática da base via GitHub Actions usando o endpoint público de resultados da Caixa.

## Publicar gratuitamente
1. Crie um repositório no GitHub.
2. Envie todos os arquivos desta pasta mantendo `.github/workflows/update-lotofacil.yml`.
3. No GitHub: Settings > Pages > Deploy from a branch > `main` / root.
4. Abra a URL gerada no Chrome Android.
5. Menu do Chrome > Adicionar à tela inicial / Instalar aplicativo.
6. O workflow pode ser executado manualmente em Actions > Atualizar Lotofácil > Run workflow e também está agendado para dias úteis.

## Observação sobre a API
O endpoint usado pelo atualizador é o endpoint público de resultados associado à CAIXA. Ele não é tratado aqui como uma API com contrato de disponibilidade garantida; se a CAIXA alterar o endpoint, o workflow precisa ser ajustado.
